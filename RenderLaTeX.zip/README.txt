Installation Instructions:

1. Extract all files from this ZIP to a folder on your computer (e.g. Documents\ExcelAddins).
2. In Excel, go to File > Options > Trust Center > Trust Center Settings > Trusted Locations.
3. Add the folder where you extracted the add-in as a Trusted Location.
4. Open Excel, then go to File > Options > Add-ins > Manage Excel Add-ins > Go.
5. Browse to the extracted folder and select LaTeXRenderer.xlam.
6. If you get security warnings, right-click LaTeXRenderer.xlam > Properties > Unblock > OK.
7. If that is not an option, open PowerShell as administrator and run the following: Unblock.File -Path ":C\yourfilepath\LaTeXRender.xlam"